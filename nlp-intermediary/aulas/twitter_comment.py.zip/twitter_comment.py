# importando as bibliotecas necessárias
import pandas as pd
import re
import nltk
import spacy
from nltk.sentiment.vader import SentimentIntensityAnalyzer
from nltk.corpus import stopwords
from sklearn.feature_extraction.text import CountVectorizer

# carregando o modelo em inglês do Spacy para realizar a análise linguística
nlp = spacy.load("en_core_web_sm")

# carregando o analisador de sentimentos do NLTK
sia = SentimentIntensityAnalyzer()

# carregando as stop words em inglês do NLTK
english_stopwords = list(stopwords.words('english'))

# lendo o arquivo csv que contém os tweets e criando um dataframe
df = pd.read_csv('./datasets/twitter_training.csv', header=None)

# renomeando as colunas do dataframe
df.columns = ['id', 'topic', 'sentiment', 'tweet']

# removendo as linhas que contêm valores ausentes
df.dropna(inplace=True, axis=0)

# selecionando as primeiras 10 linhas do dataframe para fins de exemplo
df = df[0:10]


# função para remover as stop words (palavras comuns que não carregam significado) dos textos
def remove_stopwords(text):
    for z in english_stopwords:
        # substituindo as stop words encontradas por uma string vazia
        text = re.sub(r'\b' + z + r'\b', "", text, flags=re.IGNORECASE)
    return text


# função para realizar o pré-processamento dos textos, como remover URLs, pontuações e stop words
def preprocessing(text):
    # substituindo múltiplos espaços em branco por um único espaço
    text = re.sub(r"\s+", " ", text)

    # removendo URLs dos textos
    text = re.sub(r"(?i)\b((?:https?:\/|pic\.|www\d{0,3}[.]|[a-z0-9.\-]+[.][a-z]{2,4}\/)(?:[^\s()<>]+|\(([^\s()<>]+|(\([^\s()<>]+\)))*\))+(?:\(([^\s()<>]+|(\([^\s()<>]+\)))*\)|[^\s`!()\[\]{};:'\".,<>?«»“”‘’]))", "", text)

    # removendo as stop words dos textos
    text = remove_stopwords(text)

    # removendo espaços em branco no início e no final dos textos
    text = text.strip().rstrip()

    return text


# função para lematizar os tokens dos textos (transformar em suas formas lematizadas, ex.: "correndo" -> "correr")
def text_lemmatise(text):
    # criando um objeto do Spacy para realizar a análise linguística
    doc = nlp(text)

    # criando uma lista para armazenar as formas lematizadas dos tokens
    list_lemmas = []
    for token in doc:
        # adicionando a forma lematizada do token na lista, se ela não for uma string vazia
        list_lemmas.append(token.lemma_)
    list_lemmas = list(filter(str.strip, list_lemmas))

    # juntando as formas lematizadas dos tokens em uma única string
    sentence = ""
    for z in list_lemmas:
        sentence = sentence + " " + str(z)
        sentence = sentence.strip()

    return sentence


# Essa função recebe uma string x como entrada
def clean_text(x):
    # Pré-processa a string usando a função 'preprocessing'
    x = preprocessing(x)

    # Executa a lematização do texto usando a função 'text_lemmatise'
    x = text_lemmatise(x)

    # Retorna a string pré-processada e lematizada
    return x


# Essa função recebe um objeto x como entrada
def get_unique_labels(x):
    # Cria uma lista com as entidades do objeto x e retorna a lista de rótulos únicos
    return list(set(entity.label_ for entity in x.ents))


# Essa função recebe uma linha de um DataFrame como entrada
def fn_counts(row):
    # Extrai o texto processado da coluna 'tweet_nlp'
    x = row['tweet_nlp']

    # Extrai os rótulos das entidades da coluna 'tweet_labels'
    row_labels = row['tweet_labels']

    # Cria um dicionário para contar as ocorrências de cada parte da fala e de cada rótulo de entidade
    pos_counts = {
        'nouns': sum([1 for token in x if token.pos_ == 'NOUN']),
        'verbs': sum([1 for token in x if token.pos_ == 'VERB']),
        'adjectives': sum([1 for token in x if token.pos_ == 'ADJ']),
        'positive': sum([1 for token in x if sia.polarity_scores(token.text)['pos'] > 0]),
        'negative': sum([1 for token in x if sia.polarity_scores(token.text)['neg'] > 0]),
    }

    label_counts = {}
    for label in row_labels:
        if label in label_counts:
            label_counts[label] += 1
        else:
            label_counts[label] = 1

    # Retorna um dicionário com as contagens de cada parte da fala e de cada rótulo de entidade
    return {**pos_counts, **label_counts}


# Função que gera n-grams de palavras com base em um conjunto de dados de entrada e parâmetros especificados
# Parâmetros:
# - X: conjunto de dados de entrada
# - word_max_features_in: número máximo de features (palavras) a serem consideradas
# - word_min_df_in: frequência mínima com que uma palavra deve aparecer para ser considerada
# - word_max_df_in: frequência máxima com que uma palavra pode aparecer para ser considerada
# - wordgram_range_in: range de n-grams de palavras a serem gerados (exemplo: (1,2) para unigrams e bigrams)
# - verbose: se verdadeiro, exibe informações sobre o resultado da geração dos n-grams
# - feature_objetive: a feature do conjunto de dados a ser usada para gerar os n-grams

def generate_word_ngrams(X, word_max_features_in, word_min_df_in, word_max_df_in, wordgram_range_in, verbose,
                         feature_objetive):
    # Cria um objeto CountVectorizer com os parâmetros especificados
    count_vect_word = CountVectorizer(
        analyzer='word',
        lowercase=True,
        max_features=word_max_features_in,
        min_df=word_min_df_in,
        max_df=word_max_df_in,
        ngram_range=wordgram_range_in
    )

    # Executa a contagem de frequência das palavras na feature especificada do conjunto de dados e retorna o resultado em um formato sparse matrix
    result_w = count_vect_word.fit_transform(X[feature_objetive])

    # Se verbose for verdadeiro, exibe informações sobre o resultado da contagem de frequência das palavras
    if (verbose):
        print(str(result_w.shape))

    # Usa o objeto CountVectorizer para transformar a feature especificada do conjunto de dados em uma matriz de n-grams
    X_train_ngrams = count_vect_word.transform(X[feature_objetive])

    # Obtém uma lista com os n-grams gerados pelo objeto CountVectorizer
    list_n_grams = count_vect_word.get_feature_names_out()

    # Retorna a matriz de n-grams e a lista de n-grams gerados
    return (X_train_ngrams, list_n_grams)


# Aplicamos a função clean_text a todos os tweets
df['tweet_cleaned'] = df['tweet'].apply(lambda x: clean_text(x))

# convertemos os tweets limpos para nlp
df['tweet_nlp'] = df['tweet_cleaned'].apply(lambda x: nlp(x))

# buscamos os labels de cada tweet
df['tweet_labels'] = df['tweet_nlp'].apply(lambda x: get_unique_labels(x))

# contamos as informações gerais de cada tweet
df['tweet_labels_count'] = df.apply(lambda x: fn_counts(x), axis=1)

# Aplicamos a função generate_word_ngrams no dataframe com range de 1,5
X_train_ngrams, list_n_grams = generate_word_ngrams(X=df,
                                                    word_max_features_in=None,
                                                    word_min_df_in=1,
                                                    word_max_df_in=0.5,
                                                    wordgram_range_in=(1,5),
                                                    verbose=True,
                                                    feature_objetive='tweet_cleaned')

# Exibimos o shape da matriz de n-gram
print(X_train_ngrams.shape)

# Exibimos o resultado da matriz de n-gram
print(list_n_grams)

# Exibimos as contagens das informações gerais dos tweets
df['tweet_labels_count'].apply(lambda x: print(x))

